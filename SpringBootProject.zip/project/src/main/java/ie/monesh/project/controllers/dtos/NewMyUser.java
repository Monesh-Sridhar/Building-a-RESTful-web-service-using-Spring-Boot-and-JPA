package ie.monesh.project.controllers.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record NewMyUser(
        @NotEmpty(message = "User's email cannot be empty")
        @NotBlank(message = "User's email cannot be blank")
        @NotNull(message = "User's email cannot be null")
        String email,

        @NotEmpty(message = "User's password cannot be empty")
        @NotBlank(message = "User's password cannot be blank")
        @NotNull(message = "User's password cannot be null")
        String password,
        @NotNull(message = "User's locked status cannot be null")
        Boolean locked,

        @NotEmpty(message = "User's role cannot be empty")
        @NotBlank(message = "User's role cannot be blank")
        @NotNull(message = "User's role cannot be null")
        String role,

        @NotEmpty(message = "User's phone number cannot be empty")
        @NotBlank(message = "User's phone number cannot be blank")
        @NotNull(message = "User's phone number cannot be null")
        String phoneNumber,

        @NotEmpty(message = "User's ppsn cannot be empty")
        @NotBlank(message = "User's ppsn cannot be blank")
        @NotNull(message = "User's ppsn cannot be null")
        String ppsn){
}
