package ie.monesh.project.handlers;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class CapacityReachedException extends RuntimeException{

    public CapacityReachedException(String message) {
        super(message);
    }

}
