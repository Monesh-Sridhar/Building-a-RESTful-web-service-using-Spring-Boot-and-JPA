package ie.monesh.project.controllers;

import ie.monesh.project.controllers.dtos.NewProperty;
import ie.monesh.project.controllers.dtos.NewTenant;
import ie.monesh.project.entities.Property;
import ie.monesh.project.entities.Tenant;
import ie.monesh.project.handlers.CapacityReachedException;
import ie.monesh.project.handlers.ResourceNotFoundException;
import ie.monesh.project.repositories.PropertyRepository;
import ie.monesh.project.repositories.TenantRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tenants")
public class TenantController {

    private TenantRepository tenantRepository;


    private PropertyRepository propertyRepository;

    @Autowired
    public TenantController(TenantRepository tenantRepository, PropertyRepository propertyRepository){
        this.tenantRepository = tenantRepository;
        this.propertyRepository = propertyRepository;
    }

    //localhost:8080/api/tenants/1      returns 200 OK
    //localhost:8080/api/tenants/29    returns 404 not found with error message
    @GetMapping("/{id}")
    Tenant findById(@PathVariable("id") int tenantId){
        Optional<Tenant> tenantOptional = tenantRepository.findById(tenantId);
        if(tenantOptional.isPresent())
            return tenantOptional.get();
        throw new ResourceNotFoundException("Tenant with ID " + tenantId + " is not present");
    }

    //localhost:8080/api/tenants/in/property/1     returns 200 OK
    //localhost:8080/api/tenants/in/property/10    returns 404 Not found with Error message
    @GetMapping("in/property/{id}")
    List<Tenant> findAllTenantsInAProperty(@PathVariable("id") int propertyId) {
        Optional<Property> propertyOptional = propertyRepository.findById(propertyId);

        if (propertyOptional.isPresent()) {
            Property property = propertyOptional.get();
            return tenantRepository.findAllByProperty_PropertyId(property.getPropertyId());
        } else {
            throw new ResourceNotFoundException("Property with ID " + propertyId + " is not present");
        }
    }


    //localhost:8080/api/tenants/1       returns 204 No Content
    //localhost:8080/api/tenants/199     returns 404 Not found with Error message
    @DeleteMapping({"/{id}"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void deletedById(@PathVariable("id") int tenantId){
        if(tenantRepository.existsById(tenantId))
            tenantRepository.deleteById(tenantId);
        else
            throw new ResourceNotFoundException("Tenant with ID " + tenantId + " is not present.");
    }

    //localhost:8080/api/tenants/   returns 201 Created
    //{
    //        "tenantName": "saran",
    //        "tenantEmailId": "mmm@my.ie",
    //        "tenantPhoneNo": "8986567876",
    //        "propertyId": 1
    //}
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping({"/",""})
    Tenant addTenant(@Valid @RequestBody NewTenant newTenant) {
        Optional<Property> propertyOptional = propertyRepository.findById(newTenant.propertyId());
        if (propertyOptional.isPresent()) {
            Property property = propertyOptional.get();
            int currentTenantsCount = propertyRepository.countTenantsByPropertyId(property.getPropertyId());
            if (currentTenantsCount < property.getCapacityOfProperty())
                return tenantRepository.save(new Tenant(newTenant.tenantName(), newTenant.tenantEmailId(), newTenant.tenantPhoneNo(), property));
            else
                throw new CapacityReachedException("Property with ID " + newTenant.propertyId() + " has reached its capacity");
        }
        else
            throw new ResourceNotFoundException("Property with ID " + newTenant.propertyId() + " does not exists");
    }


    //localhost:8080/api/tenants/move/1/to/3     returns 200 OK
    //localhost:8080/api/tenants/move/1/to/2     returns 400 Bad Request with Error message
    //localhost:8080/api/tenants/move/100/to/3   returns 404 Not Found with Error message
    @PatchMapping("/move/{tenantId}/to/{propertyId}")
    void moveTenantToNewProperty(@PathVariable("tenantId") int tenantId, @PathVariable("propertyId") int propertyId) {
        Property property = propertyRepository.findById(propertyId)
                .orElseThrow(() -> new ResourceNotFoundException("Property with ID " + propertyId + " does not exists"));
        Tenant tenant = tenantRepository.findById(tenantId)
                .orElseThrow(() -> new ResourceNotFoundException("Tenant with ID " + tenantId + " does not exist"));
        if (property.getTenants().size() < property.getCapacityOfProperty()) {
            tenantRepository.moveTenantToNewProperty(tenantId, propertyId);
        } else {
            throw new CapacityReachedException("property with ID " + propertyId + " has reached its capacity");
        }
    }

}




