package ie.monesh.project.controllers;

import ie.monesh.project.controllers.dtos.NewProperty;
import ie.monesh.project.controllers.dtos.NewRent;
import ie.monesh.project.controllers.dtos.PropertyWithTenantsCount;
import ie.monesh.project.entities.Property;
import ie.monesh.project.entities.Tenant;
import ie.monesh.project.handlers.ResourceNotFoundException;
import ie.monesh.project.repositories.PropertyRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/properties")
public class PropertyController {

    @Autowired private PropertyRepository propertyRepository;

    //localhost:8080/api/properties    returns 200 OK
    @GetMapping({"/",""})
    List<Property> findAll(){

        return propertyRepository.findAll();
    }

    //localhost:8080/api/properties/availability     returns 200 OK
    @GetMapping("/availability")
    List<Property> findPropertiesWithAvailability() {

        return propertyRepository.findPropertiesWithAvailability();
    }

    //localhost:8080/api/properties/current/tenants/count/1      returns 200 OK
    //localhost:8080/api/properties/current/tenants/count/60     returns 404 Not found with Error message
    @GetMapping("/current/tenants/count/{id}")
    PropertyWithTenantsCount findPropertyWithTenantCount(@PathVariable("id") int propertyId) {
        return propertyRepository.findPropertyWithTenantsCount(propertyId)
                .orElseThrow(() -> new ResourceNotFoundException("Property with ID " + propertyId + " is not present"));
    }

    //localhost:8080/api/properties/total/rental    returns 200
    @GetMapping("/total/rental")
    Integer getTotalRentalIncome() {

        return propertyRepository.getTotalRentalIncome();
    }


    //localhost:8080/api/properties/1/rent    returns 200 OK
    //localhost:8080/api/properties/100/rent  404 Not Found
    //{
    //    "newRent" : 50000
    //}
    @PatchMapping("/{id}/rent")
    Property updateRent(@Valid @RequestBody NewRent newRent, @PathVariable("id") int propertyId){
        if(propertyRepository.existsById(propertyId)){
            propertyRepository.updateCostOfProperty(propertyId, newRent.newRent());
            return propertyRepository.findById(propertyId).get();
        }
        throw new ResourceNotFoundException("Property with ID " + propertyId + " is not present.");
    }

    //localhost:8080/api/properties/2         returns 204 No Content
    //localhost:8080/api/properties/23        returns 404 Not found with Error message
    @DeleteMapping({"/{id}"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    void deletedById(@PathVariable("id") int propertyId){
        if(propertyRepository.existsById(propertyId))
            propertyRepository.deleteById(propertyId);
        else
            throw new ResourceNotFoundException("Property with ID " + propertyId + " is not present.");
    }

    //localhost:8080/api/properties   returns 201 Created
    //{
    //    "address": "12 chennai",
    //    "eirCode": "IK97H",
    //    "capacityOfProperty": 2,
    //    "costOfProperty": 2000
    //}
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping({"/",""})
    Property addProperty(@Valid @RequestBody NewProperty newProperty){
        return propertyRepository.save(new Property(newProperty.address(), newProperty.eirCode(), newProperty.capacityOfProperty(), newProperty.costOfProperty()));
    }

    //localhost:8080/api/properties/1     for Unit testing
    @GetMapping("/{id}")
    Property findById(@PathVariable("id") int propertyId){
        Optional<Property> propertyOptional = propertyRepository.findById(propertyId);
        if(propertyOptional.isPresent())
            return propertyOptional.get();
        throw new ResourceNotFoundException("Tenant with ID " + propertyId + " is not present");
    }
}
