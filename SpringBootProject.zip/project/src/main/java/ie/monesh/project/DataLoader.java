package ie.monesh.project;


import ie.monesh.project.entities.MyUser;
import ie.monesh.project.entities.Property;
import ie.monesh.project.entities.Tenant;
import ie.monesh.project.repositories.MyUserRepository;
import ie.monesh.project.repositories.PropertyRepository;
import ie.monesh.project.repositories.TenantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Profile("dev")
@Component
public class DataLoader implements CommandLineRunner {

    private PropertyRepository propertyRepository;
    private TenantRepository tenantRepository;

    private MyUserRepository myUserRepository;

    @Autowired
    public DataLoader(PropertyRepository propertyRepository, TenantRepository tenantRepository, MyUserRepository myUserRepository){
        this.propertyRepository = propertyRepository;
        this.tenantRepository = tenantRepository;
        this.myUserRepository = myUserRepository;
    }



    @Override
    public void run(String... args) throws Exception {

        Property evergreen = propertyRepository.save(new Property( "123 Main Street", "EIR123", 5, 3000));
        Property luminary = propertyRepository.save(new Property("456 Oak Avenue", "EIR456", 3, 2500));
        Property homestead = propertyRepository.save(new Property("789 Pine Lane", "EIR789", 5, 5000));
        Property crestview = propertyRepository.save(new Property("101 Maple Street", "EIR101", 4, 4500));
        Property sunbeam = propertyRepository.save(new Property("202 Cedar Avenue", "EIR202", 4, 2500));
        Property havencrest = propertyRepository.save(new Property("303 Elm Lane", "EIR303", 3, 1500));


        tenantRepository.save(new Tenant("Aron","aron@mail.com","9878768798", evergreen));
        tenantRepository.save(new Tenant("Alice", "alice@mail.com", "1234586789",havencrest ));
        tenantRepository.save(new Tenant("Bob", "bob@mail.com", "9876543721", homestead));
        tenantRepository.save(new Tenant("Eva", "eva@mail.com", "5551283456", crestview));
        tenantRepository.save(new Tenant("David", "david@mail.com", "9899888777", sunbeam));
        tenantRepository.save(new Tenant("Sophie", "sophie@mail.com", "1116222333", crestview));
        tenantRepository.save(new Tenant("Chris", "chris@mail.com", "4445585666",luminary ));
        tenantRepository.save(new Tenant("Olivia", "olivia@mail.com", "7778788999",havencrest ));
        tenantRepository.save(new Tenant("Daniel", "daniel@mail.com", "3337222111", crestview));
        tenantRepository.save(new Tenant("Emma", "emma@mail.com", "6549987321", homestead));
        tenantRepository.save(new Tenant("Ryan", "ryan@mail.com", "1293789456", evergreen));
        tenantRepository.save(new Tenant("Grace", "grace@mail.com", "4569987123", evergreen));
        tenantRepository.save(new Tenant("Kevin", "kevin@mail.com", "7896574321", havencrest));
        tenantRepository.save(new Tenant("Lily", "lily@mail.com", "9873201654", luminary));
        tenantRepository.save(new Tenant("Michael", "michael@mail.com", "4567123789", sunbeam));
        tenantRepository.save(new Tenant("Sophia", "sophia@mail.com", "9871923456", crestview));
        tenantRepository.save(new Tenant("William", "william@mail.com", "3216987654", homestead));
        tenantRepository.save(new Tenant("Ava", "ava@mail.com", "6547893021", luminary));
        tenantRepository.save(new Tenant("James", "james@mail.com", "7897123456", sunbeam));
        tenantRepository.save(new Tenant("Emily", "emily@mail.com", "3214956789", homestead));


        PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();

        myUserRepository.save(new MyUser("monesh.@mtu.ie", passwordEncoder.encode("Monesh@100"), false,"MANAGER", "0847474747", "POI87LK"));
        myUserRepository.save(new MyUser("user2@example.com", passwordEncoder.encode("Passw0rd2"), false, "OFFICE_STAFF", "1234567890", "ABC123"));
        myUserRepository.save(new MyUser("admin3@example.com", passwordEncoder.encode("SecurePwd3"), true, "OFFICE_STAFF", "9876543210", "XYZ789"));
        myUserRepository.save(new MyUser("john_doe4@example.com", passwordEncoder.encode("P@ssword4"), true, "MANAGER", "5550001234", "DEF456"));


    }
}
