package ie.monesh.project.repositories;

import ie.monesh.project.entities.Tenant;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TenantRepository extends JpaRepository<Tenant, Integer> {

    List<Tenant> findAllByProperty_PropertyId(int PropertyId);

    @Modifying
    @Transactional
    @Query("UPDATE Tenant t SET t.property.propertyId = :propertyId WHERE t.tenantId = :tenantId")
    void moveTenantToNewProperty(@Param("tenantId") int tenantId, @Param("propertyId") int propertyId);
}
