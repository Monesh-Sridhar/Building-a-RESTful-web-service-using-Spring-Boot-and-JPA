package ie.monesh.project.controllers.dtos;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public record NewRent(
        @Min(value = 0, message = "Property's rent must be at least 0")
        @NotNull(message = "Property's rent must be provided and be at least 0")
        Integer newRent
) {
}
