package ie.monesh.project;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
public class SecurityConfig {

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .authorizeHttpRequests(auth ->{
                    auth.requestMatchers(HttpMethod.GET, "/api/properties/**").permitAll()
                            .requestMatchers(HttpMethod.GET,"/api/tenants/**").hasAnyRole("OFFICE_STAFF","MANAGER")
                            .requestMatchers(HttpMethod.POST,"/api/tenants/**").hasAnyRole("OFFICE_STAFF","MANAGER")
                            .requestMatchers(HttpMethod.PATCH,"/api/tenants/**").hasAnyRole("OFFICE_STAFF","MANAGER")
                            .requestMatchers(HttpMethod.DELETE,"/api/tenants/**").hasAnyRole("OFFICE_STAFF","MANAGER")
                            .requestMatchers(HttpMethod.POST,"/api/properties/**").hasRole("MANAGER")
                            .requestMatchers(HttpMethod.PATCH,"/api/properties/**").hasRole("MANAGER")
                            .requestMatchers(HttpMethod.DELETE,"/api/properties/**").hasRole("MANAGER")
                            .requestMatchers(HttpMethod.GET,"/api/users/**").hasRole("MANAGER")
                            .requestMatchers(HttpMethod.POST,"/api/users/**").hasRole("MANAGER")
                            .requestMatchers(HttpMethod.PATCH,"/api/users/**").hasRole("MANAGER")
                            .requestMatchers(HttpMethod.DELETE,"/api/users/**").hasRole("MANAGER")
                            .requestMatchers("/graphql").permitAll()
                            .anyRequest().authenticated();
                })
                .csrf(AbstractHttpConfigurer::disable)
                .httpBasic(Customizer.withDefaults())
                .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .build();
    }
}
