package ie.monesh.project.repositories;

import ie.monesh.project.controllers.dtos.PropertyWithTenantsCount;
import ie.monesh.project.entities.Property;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface PropertyRepository extends JpaRepository<Property, Integer> {

    @Query("SELECT p FROM Property p LEFT JOIN p.tenants t GROUP BY p HAVING COUNT(t) < p.capacityOfProperty")
    List<Property> findPropertiesWithAvailability();

    @Query("SELECT new ie.monesh.project.controllers.dtos.PropertyWithTenantsCount(p, size(p.tenants)) FROM Property p WHERE p.propertyId = :propertyId")
    Optional<PropertyWithTenantsCount> findPropertyWithTenantsCount(@Param("propertyId") int propertyId);

    @Query("SELECT SUM(p.costOfProperty) FROM Property p WHERE SIZE(p.tenants) > 0")
    Integer getTotalRentalIncome();

    @Query("SELECT COUNT(t) FROM Property p JOIN p.tenants t WHERE p.propertyId = :propertyId")
    int countTenantsByPropertyId(@Param("propertyId") int propertyId);

    @Modifying
    @Transactional
    @Query("UPDATE Property p SET p.costOfProperty = :newRent WHERE p.propertyId = :propertyId")
    void updateCostOfProperty(@Param("propertyId") int propertyId, @Param("newRent") int newRent);
}
