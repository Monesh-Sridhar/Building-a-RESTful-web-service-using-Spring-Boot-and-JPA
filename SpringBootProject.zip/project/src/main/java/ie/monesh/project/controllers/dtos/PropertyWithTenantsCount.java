package ie.monesh.project.controllers.dtos;

import ie.monesh.project.entities.Property;

public record PropertyWithTenantsCount(Property property, int tenantsCount) {
}
