package ie.monesh.project.controllers.dtos;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public record NewProperty(
        @NotEmpty(message = "Property's address cannot be empty")
        @NotBlank(message = "Property's address cannot be blank")
        @NotNull(message = "Property's address cannot be null")
        String address,

        @NotEmpty(message = "Property's eircode cannot be empty")
        @NotBlank(message = "Property's eircode cannot be blank")
        @NotNull(message = "Property's eircode cannot be null")
        String eirCode,

        @Min(value = 0, message = "Property's capacity must be at least 0")
        @NotNull(message = "Property's capacity must be provided and be least 0")
        Integer capacityOfProperty,

        @Min(value = 0, message = "Property's cost must be at least 0")
        @NotNull(message = "Property's cost must be provided and be least 0")
        Integer costOfProperty) {
}
