package ie.monesh.project.controllers;

import ie.monesh.project.controllers.dtos.NewMyUser;
import ie.monesh.project.entities.MyUser;
import ie.monesh.project.repositories.MyUserRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class MyUserController {

    @Autowired private MyUserRepository myUserRepository;

    //localhost:8080/api/users   returns 201 Created
    //{
    //        "email": "sridhar.@mtu.ie",
    //        "password": "Monesh@200",
    //        "locked": "false",
    //        "role": "MANAGER",
    //        "phoneNumber": "9878787657",
    //        "ppsn": "9I9KJ8HY"
    //}
    @ResponseStatus(HttpStatus.CREATED)
    @PostMapping({"/",""})
    MyUser addUser(@Valid @RequestBody NewMyUser newMyUser){
        if(myUserRepository.existsById(newMyUser.email())){
            throw new DataIntegrityViolationException("This Email id already exists.");
        }
        return myUserRepository.save(new MyUser(newMyUser.email(), newMyUser.password(), newMyUser.locked(), newMyUser.role(), newMyUser.phoneNumber(), newMyUser.ppsn()));
    }
}
