package ie.monesh.project.controllers;

import ie.monesh.project.entities.Property;
import ie.monesh.project.entities.Tenant;
import ie.monesh.project.repositories.PropertyRepository;
import ie.monesh.project.repositories.TenantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class GraphQLController {

    @Autowired
    private PropertyRepository propertyRepository;

    @Autowired
    private TenantRepository tenantRepository;

    @QueryMapping(value = "properties")
    List<Property> getAllProperties(){
        return propertyRepository.findAll();
    }

    @QueryMapping
    Property findProperty(@Argument int id){
        return propertyRepository.findById(id).orElse(null);
    }

    @MutationMapping
    @Secured({"ROLE_OFFICE_STAFF","ROLE_MANAGER"})
    Tenant createTenant(@Argument("tenantName") String tenantName, @Argument("tenantEmailId") String tenantEmailId, @Argument("tenantPhoneNo") String tenantPhoneNo, @Argument("propertyId") int propertyId){
        return tenantRepository.save(new Tenant(tenantName, tenantEmailId, tenantPhoneNo, propertyRepository.findById(propertyId).get()));
    }

    @Secured("ROLE_MANAGER")
    @MutationMapping
    int deleteProperty(@Argument int id) {
        if (propertyRepository.existsById(id)) {
            propertyRepository.deleteById(id);
            return 0;
        }
        return -1;
    }
}
