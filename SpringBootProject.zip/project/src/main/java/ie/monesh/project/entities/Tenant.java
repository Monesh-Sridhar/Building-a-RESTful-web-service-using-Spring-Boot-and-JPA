package ie.monesh.project.entities;



import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Tenants")
public class Tenant {

    @Id
    @GeneratedValue
    private int tenantId;

    @Column(nullable = false)
    private String tenantName;

    @Column(unique = true)
    private String tenantEmailId;

    @Column(unique = true)
    private String tenantPhoneNo;

    @ManyToOne
    @JoinColumn(name="property_id")
    @JsonIgnore
    private Property property;

    public Tenant(String tenantName, String tenantEmailId,String tenantPhoneNo,Property property ){
        this.tenantName = tenantName;
        this.tenantEmailId = tenantEmailId;
        this.tenantPhoneNo = tenantPhoneNo;
        this.property = property;
    }
}
