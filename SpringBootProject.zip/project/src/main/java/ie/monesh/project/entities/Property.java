package ie.monesh.project.entities;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="Properties")
public class Property {
    @Id
    @GeneratedValue
    private int propertyId;

    @Column(unique = true)
    private String address;

    @Column(unique = true)
    private String eirCode;

    private int capacityOfProperty;

    private int costOfProperty;

    @OneToMany(mappedBy = "property", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @ToString.Exclude
    @JsonIgnore
    private List<Tenant> tenants;

    public Property(String address, String eirCode, int capacityOfProperty, int costOfProperty) {
        this.address = address;
        this.eirCode = eirCode;
        this.capacityOfProperty = capacityOfProperty;
        this.costOfProperty = costOfProperty;
    }
}
