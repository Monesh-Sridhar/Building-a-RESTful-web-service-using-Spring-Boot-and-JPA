package ie.monesh.project;

import ie.monesh.project.entities.Property;
import ie.monesh.project.entities.Tenant;
import ie.monesh.project.repositories.PropertyRepository;
import ie.monesh.project.repositories.TenantRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MockMvcBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Optional;

import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

@SpringBootTest
@AutoConfigureMockMvc
class RestTests {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	PropertyRepository propertyRepository;

	@MockBean
	TenantRepository tenantRepository;

	@Test
	void givenUserIsAnonymous_whenGet_thenOk() throws Exception{
		Property evergreen = new Property( "123 Main Street", "EIR123", 5, 3000);
		given(propertyRepository.findById(1)).willReturn(Optional.of(evergreen));
		mockMvc.perform(MockMvcRequestBuilders.get("/api/properties/1"))
				.andExpect(MockMvcResultMatchers.status().isOk());
	}

	@Test
	void givenUserIsAnonymous_whenGetWithNonExistingId_thenNotFound() throws Exception {
		given(propertyRepository.findById(2)).willReturn(Optional.empty());
		mockMvc.perform(MockMvcRequestBuilders.get("/api/properties/2"))
				.andExpect(MockMvcResultMatchers.status().isNotFound());
	}

	@Test
	@WithMockUser(username = "manager", roles = "MANAGER")
	void givenUserIsAuthorized_whenDeleteWithExistingId_thenNoContent() throws Exception {
		when(tenantRepository.existsById(1)).thenReturn(true);
		mockMvc.perform( MockMvcRequestBuilders
						.delete("/api/tenants/{id}",1))
				.andExpect(MockMvcResultMatchers.status().isNoContent());
	}

	@Test
	@WithMockUser(username = "admin", roles = "ADMIN")
	void givenUserIsAuthenticatedButNotAuthorized_whenDeleteWithExistingId_thenForbidden() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders
						.delete("/api/tenants/{id}",1))
				.andExpect(MockMvcResultMatchers.status().isForbidden());
	}

	@Test
	void givenUserIsNotAuthenticated_whenDeleteWithExistingId() throws Exception {
		mockMvc.perform(MockMvcRequestBuilders
						.delete("/api/tenants/{id}", 1))
				.andExpect(MockMvcResultMatchers.status().isUnauthorized());
	}






}
